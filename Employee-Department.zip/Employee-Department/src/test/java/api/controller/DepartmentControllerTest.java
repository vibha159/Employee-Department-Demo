package api.controller;

import api.dto.Department;
import api.service.DepartmentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.util.Assert;

import java.util.Arrays;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(DepartmentController.class)
public class DepartmentControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private DepartmentService departmentService;

    @Autowired
    private ObjectMapper objectMapper;

    private Department department;

    @BeforeEach
    void setup() {
        department = new Department();
        department.setId(1L);
        department.setDepartmentName("IT");
    }

    @Test
    void testCreateDepartment() throws Exception {
        Mockito.when(departmentService.saveDepartment(any(Department.class)))
                .thenReturn(department);

        mockMvc.perform(post("/api/department/create")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(department)))

                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(department.getId()))
                .andExpect(jsonPath("$.departmentName").value(department.getDepartmentName()));
    }


    @Test
    void testGetAllDepartments() throws Exception {
        List<Department> departments = Arrays.asList(department);
        Mockito.when(departmentService.getAllDepartments()).thenReturn(departments);

        mockMvc.perform(get("/api/department/getAll"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(department.getId()));
    }

    @Test
    void testGetDepartmentById() throws Exception {
        Mockito.when(departmentService.getDepartmentById(1L)).thenReturn(department);

        mockMvc.perform(get("/api/department/getById/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L));
    }

    @Test
    void testUpdateDepartment() throws Exception {
        Mockito.when(departmentService.updateDepartment(any(Department.class)))
                .thenReturn(department);

        mockMvc.perform(put("/api/department/update/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(department)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.departmentName").value("IT"));
    }

    @Test
    void testDeleteDepartment() throws Exception {
        Mockito.doNothing().when(departmentService).deleteDepartment(1L);

        mockMvc.perform(delete("/api/department/delete/1"))
                .andExpect(status().isOk());
    }
}

