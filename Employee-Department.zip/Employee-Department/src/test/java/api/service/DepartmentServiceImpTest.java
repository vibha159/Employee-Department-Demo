package api.service;

import api.dto.Department;
import api.repository.DepartmentRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest
class DepartmentServiceImplTest {

    @InjectMocks
    private DepartmentServiceImpl departmentService;

    @Mock
    private DepartmentRepository departmentRepository;

    private Department sampleDepartment;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        sampleDepartment = new Department();
        sampleDepartment.setId(1L);
        sampleDepartment.setDepartmentName("Engineering");
    }

    @Test
    void testSaveDepartment() {
        when(departmentRepository.save(any(Department.class))).thenReturn(sampleDepartment);

        Department saved = departmentService.saveDepartment(sampleDepartment);

        assertNotNull(saved);
        assertEquals("Engineering", saved.getDepartmentName());
        verify(departmentRepository, times(1)).save(sampleDepartment);
    }

    @Test
    void testUpdateDepartment() {
        when(departmentRepository.findById(1L)).thenReturn(Optional.of(sampleDepartment));
        when(departmentRepository.save(any(Department.class))).thenReturn(sampleDepartment);

        sampleDepartment.setDepartmentName("Updated Name");

        Department updated = departmentService.updateDepartment(sampleDepartment);

        assertNotNull(updated);
        assertEquals("Updated Name", updated.getDepartmentName());
        verify(departmentRepository).findById(1L);
        verify(departmentRepository).save(sampleDepartment);
    }

    @Test
    void testUpdateDepartment_NotFound() {
        when(departmentRepository.findById(1L)).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            departmentService.updateDepartment(sampleDepartment);
        });

        assertEquals("Deparment not found", exception.getMessage());
        verify(departmentRepository, never()).save(any());
    }

    @Test
    void testDeleteDepartment() {
        doNothing().when(departmentRepository).deleteById(1L);

        departmentService.deleteDepartment(1L);

        verify(departmentRepository, times(1)).deleteById(1L);
    }

    @Test
    void testGetDepartmentById() {
        when(departmentRepository.getReferenceById(1L)).thenReturn(sampleDepartment);

        Department dept = departmentService.getDepartmentById(1L);

        assertNotNull(dept);
        assertEquals(1L, dept.getId());
        verify(departmentRepository).getReferenceById(1L);
    }

    @Test
    void testGetAllDepartments() {
        when(departmentRepository.findAll()).thenReturn(Arrays.asList(sampleDepartment));

        List<Department> departments = departmentService.getAllDepartments();

        assertNotNull(departments);
        assertEquals(1, departments.size());
        assertEquals("Engineering", departments.get(0).getDepartmentName());
        verify(departmentRepository).findAll();
    }
}
