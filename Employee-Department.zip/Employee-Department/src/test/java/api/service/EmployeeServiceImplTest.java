package api.service;

import api.dto.Department;
import api.dto.Employee;
import api.repository.EmployeeRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest
class EmployeeServiceImplTest {

    @InjectMocks
    private EmployeeServiceImpl employeeService;

    @Mock
    private EmployeeRepository employeeRepository;

    private Employee sampleEmployee;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        sampleEmployee = new Employee();
        sampleEmployee.setId(1L);
        sampleEmployee.setFirstName("John");
        sampleEmployee.setLastName("Doe");
        sampleEmployee.setEmail("john.doe@example.com");

        Department dept = new Department();
        dept.setId(101L);
        dept.setDepartmentName("IT");

        sampleEmployee.setDepartment(dept);
    }

    @Test
    void testSaveEmployee() {
        when(employeeRepository.save(any(Employee.class))).thenReturn(sampleEmployee);

        Employee saved = employeeService.saveEmployee(sampleEmployee);

        assertNotNull(saved);
        assertEquals("John", saved.getFirstName());
        verify(employeeRepository, times(1)).save(sampleEmployee);
    }

    @Test
    void testUpdateEmployee() {
        when(employeeRepository.findById(1L)).thenReturn(Optional.of(sampleEmployee));
        when(employeeRepository.save(any(Employee.class))).thenReturn(sampleEmployee);

        sampleEmployee.setFirstName("Jane");
        Employee updated = employeeService.updateEmployee(sampleEmployee);

        assertNotNull(updated);
        assertEquals("Jane", updated.getFirstName());
        verify(employeeRepository).findById(1L);
        verify(employeeRepository).save(any(Employee.class));
    }

    @Test
    void testUpdateEmployee_NotFound() {
        when(employeeRepository.findById(1L)).thenReturn(Optional.empty());

        RuntimeException ex = assertThrows(RuntimeException.class, () ->
                employeeService.updateEmployee(sampleEmployee));

        assertEquals("Employee not found", ex.getMessage());
        verify(employeeRepository, never()).save(any());
    }

    @Test
    void testDeleteEmployee() {
        doNothing().when(employeeRepository).deleteById(1L);

        employeeService.deleteEmployee(1L);

        verify(employeeRepository, times(1)).deleteById(1L);
    }

    @Test
    void testGetEmployeeById() {
        when(employeeRepository.getReferenceById(1L)).thenReturn(sampleEmployee);

        Employee result = employeeService.getEmployeeById(1L);

        assertNotNull(result);
        assertEquals("John", result.getFirstName());
        verify(employeeRepository).getReferenceById(1L);
    }

    @Test
    void testGetAllEmployees() {
        when(employeeRepository.findAll()).thenReturn(Arrays.asList(sampleEmployee));

        List<Employee> employees = employeeService.getAllEmployees();

        assertFalse(employees.isEmpty());
        assertEquals(1, employees.size());
        verify(employeeRepository).findAll();
    }
}
