document.addEventListener("DOMContentLoaded", () => {
    const tableBody = document.getElementById("employeeTableBody");
    if (!tableBody) {
        console.error("Table body not found!");
        return;
    }

    // Fetch all employees
    fetch('http://localhost:8080/api/employee/getAll', {
        method: 'GET'
    }).then(response => {
            if (!response.ok) {
                throw new Error("Failed to fetch employees: " + response.status);
            }
            return response.json();
        })
        .then(data => {
            console.log("Employees:", data);
            data.forEach(emp => {
                const row = document.createElement("tr");
                row.innerHTML = `
                <td>${emp.id}</td>
                    <td>${emp.firstName}</td>
                    <td>${emp.lastName}</td>
                    <td>${emp.email}</td>
                    <td>${emp.department?.departmentName || "N/A"}</td>
                    <td>
                        <button class="btn btn-primary" onclick="editEmployee(${emp.id}, '${emp.firstName}', '${emp.lastName}', '${emp.email}', '${emp.department?.departmentName || "N/A"}')">Edit</button>
                        <button class="btn btn-primary" onclick="deleteEmployee(${emp.id})">Delete</button>
                    </td>
                `;
                tableBody.appendChild(row);
            });
        })
        .catch(error => {
            console.error("Error fetching employees:", error);
        });
});

async function deleteEmployee(id) {
    if (confirm("Are you sure you want to delete this employee?")) {
        try {
            const response = await fetch(`http://localhost:8080/api/employee/delete/${id}`, {
                method: "DELETE"
            });

            if (response.ok) {
                alert("Employee deleted!");
                fetchEmployees(); // Refresh the list
            } else {
                alert("Failed to delete employee.");
            }
        } catch (error) {
            console.error("Error deleting employee:", error);
        }
    }
}

async function editEmployee(id, firstName, lastName, email, department) {
  window.location.href = `update-employee.html?id=${id}&firstName=${firstName}&lastName=${lastName}&email=${email}&department=${department}`;
}



