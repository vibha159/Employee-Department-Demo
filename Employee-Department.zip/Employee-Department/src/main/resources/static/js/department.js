document.addEventListener("DOMContentLoaded", () => {
    const tableBody = document.getElementById("departmentTableBody");

    if (!tableBody) {
        console.error("Table body not found!");
        return;
    }

    // Fetch all employees
    fetch("http://localhost:8080/api/department/getAll")
        .then(response => {
            if (!response.ok) {
                throw new Error("Failed to fetch department: " + response.status);
            }
            return response.json();
        })
        .then(data => {
            console.log("Department:", data);
            data.forEach(dept => {
                const row = document.createElement("tr");
                row.innerHTML = `
                    <td>${dept.id}</td>
                    <td>${dept.departmentName}</td>
                    <td>
                        <button class="btn btn-primary" onclick="editDepartment(${dept.id}, '${dept.departmentName}')">Edit</button>
                    </td>
                    `;
                tableBody.appendChild(row);
            });
        })
        .catch(error => {
            console.error("Error fetching employees:", error);
        });
});


async function editDepartment(id, departmentName) {
    window.location.href = `update-dept.html?id=${id}&departmentName=${departmentName}`;
}



