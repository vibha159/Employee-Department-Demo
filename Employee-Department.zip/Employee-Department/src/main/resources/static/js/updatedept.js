document.addEventListener("DOMContentLoaded", () => {
const urlParams = new URLSearchParams(window.location.search);

document.getElementById("id").value = urlParams.get("id");
document.getElementById("departmentName").value = urlParams.get("departmentName");
});

async function updateDepartment() {
    event.preventDefault();
    const id = document.getElementById("id").value;
    const departmentName = document.getElementById("departmentName").value;

    const updateData = { id, departmentName };

    try {
        const response = await fetch("http://localhost:8080/api/department/update/" + id, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(updateData),
        });
        if (response.ok) {
            alert("Department updated successfully!");
            window.location.href = "department-list.html";
            // Optionally, you can redirect to a different page or perform other actions
        }
    }
    catch (error) {
        console.error("Error updating department:", error);
        alert("Error updating department");
    }
}