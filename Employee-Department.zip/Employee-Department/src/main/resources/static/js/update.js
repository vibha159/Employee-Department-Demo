document.addEventListener("DOMContentLoaded", () => {
const urlParams = new URLSearchParams(window.location.search);

document.getElementById("id").value = urlParams.get("id");
document.getElementById("firstName").value = urlParams.get("firstName");
document.getElementById("lastName").value = urlParams.get("lastName");
document.getElementById("email").value = urlParams.get("email");
document.getElementById("department").value = urlParams.get("department");

});

async function updateEmployee() {
    event.preventDefault();
    const id = document.getElementById("id").value;
    const firstName = document.getElementById("firstName").value;
    const lastName = document.getElementById("lastName").value;
    const email = document.getElementById("email").value;
    const department = {
    departmentName: document.getElementById("department").value}


    const updateData = {id, firstName, lastName, email, department };

    try {
        const response = await fetch("http://localhost:8080/api/employee/update/" + id, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(updateData),
        });
        if (response.ok) {
            alert("Employee updated successfully!");
            window.location.href = "employee-list.html";
            // Optionally, you can redirect to a different page or perform other actions
        }
    }
    catch (error) {
        console.error("Error updating employee:", error);
        alert("Error updating employee");        }
    }

