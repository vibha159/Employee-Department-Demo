/*<form id="employeeForm">
   <input type="text" name="name" placeholder="Employee Name"></input>
   <input type="email" name="email" placeholder="Email"></input>
   <select name="departmentId" id="departmentSelect"></select>
   <button type="submit">Save</button>
</form>*/

fetch('http://localhost:8080/api/department/getAll')
  .then(res => res.json())
  .then(departments => {
    const select = document.getElementById('departmentSelect');
    departments.forEach(dept => {
      const option = document.createElement('option');
      option.value = dept.id;
      option.textContent = dept.departmentName;
      select.appendChild(option);
    });
  });

document.getElementById('employeeForm').addEventListener('submit', function(e) {
  e.preventDefault();

  const formData = new FormData(this);
  const payload = {
    firstName: formData.get('firstName'),
    lastName: formData.get('lastName'),
    email: formData.get('email'),
    department: {
          id: parseInt(formData.get('department'), 10)
        }
  };

  fetch('http://localhost:8080/api/employee/create', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  }).then(res => {
    if (res.ok) {
      alert("Employee saved!");
    } else {
      alert("Error saving employee");
    }
  });
});
