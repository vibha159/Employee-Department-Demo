package api.controller;

import api.dto.Department;
import api.service.DepartmentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/department")
@CrossOrigin(origins = "*")
public class DepartmentController {

    private static final Logger logger = LoggerFactory.getLogger(DepartmentController.class);

    @Autowired
    DepartmentService departmentService;

    @PostMapping("/create")
    public Department createDepartment(@RequestBody Department department) {
        logger.info("create department");
        return departmentService.saveDepartment(department);
    }

    @GetMapping("/getAll")
    public List<Department> getAllDepartment() {
        logger.info("get all department");
        return departmentService.getAllDepartments();
    }

    @GetMapping("/getById/{id}")
    public Department getDepartmentById(@PathVariable Long id) {
        logger.info("get the department based on id");
        return departmentService.getDepartmentById(id);
    }

    @PutMapping("/update/{id}")
    public Department updateDepartment(@PathVariable Long id, @RequestBody Department department) {
        logger.info("update department based on id");
        return departmentService.updateDepartment(department);
    }


    @DeleteMapping("/delete/{id}")
    public void deleteDepartment(@PathVariable Long id) {
        logger.info("delete department");
        departmentService.deleteDepartment(id);
    }

}
