package api.service;

import api.dto.Department;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface DepartmentService {

    Department saveDepartment(Department department);
    Department updateDepartment(Department department);
    void deleteDepartment(long id);
    Department getDepartmentById(long id);
    List<Department> getAllDepartments();

}
