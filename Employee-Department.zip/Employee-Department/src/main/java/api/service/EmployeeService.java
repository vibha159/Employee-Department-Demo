package api.service;

import api.dto.Employee;

import java.util.List;

public interface EmployeeService {
    Employee saveEmployee(Employee employee);
    Employee updateEmployee(Employee employee);
    void deleteEmployee(long id);
    Employee getEmployeeById(long id);
    List<Employee> getAllEmployees();

}
