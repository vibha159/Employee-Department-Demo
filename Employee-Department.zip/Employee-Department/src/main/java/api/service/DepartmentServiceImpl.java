package api.service;

import api.controller.DepartmentController;
import api.dto.Department;
import api.repository.DepartmentRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DepartmentServiceImpl implements DepartmentService {
    private static final Logger logger = LoggerFactory.getLogger(DepartmentServiceImpl.class);
    @Autowired
    private DepartmentRepository departmentRepository;
    @Override
    public Department saveDepartment(Department department) {
        logger.info("Inside saveDepartment method of DepartmentService");
        return departmentRepository.save(department);
    }

    @Override
    public Department updateDepartment(Department department) {
        Department existingDepartment = departmentRepository.findById(department.getId())
                .orElseThrow(()-> new RuntimeException("Deparment not found"));

        existingDepartment.setId(department.getId());
        existingDepartment.setDepartmentName(department.getDepartmentName());

        logger.info("Inside updateDepartment method of DepartmentService");
        return departmentRepository.save(existingDepartment);

    }

    @Override
    public void deleteDepartment(long id) {
        logger.info("Inside deleteDepartment method of DepartmentService");
        departmentRepository.deleteById(id);
    }

    @Override
    public Department getDepartmentById(long id) {
        logger.info("get the department based on id");
        return departmentRepository.getReferenceById(id);
    }

    @Override
    public List<Department> getAllDepartments() {
        logger.info("get all department");
        return departmentRepository.findAll();
    }


}
